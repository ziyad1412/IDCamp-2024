/*
Kerjakan tugas berikut untuk menyelesaikan _task_ `01-writing-comments`:
1. Buka berkas `index.js` dan tuliskan "username" akun Dicoding Anda dalam bentuk **komentar satu baris**.
2. Buka berkas `index.js` dan tuliskan teks di bawah ini dalam bentuk **komentar banyak baris**.
*/

//ziyad1412

/*
Goal tahun ini:
1. Belajar JavaScript.
2. Menjadi Front-End atau Back-End Developer.
*/
